    $('#1').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'excel'
        ]
    });
